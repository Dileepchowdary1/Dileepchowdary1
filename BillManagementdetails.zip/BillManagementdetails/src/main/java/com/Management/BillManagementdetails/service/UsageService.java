package com.Management.BillManagementdetails.service;

import java.time.LocalDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.BillManagementdetails.dto.UsageCrtDto;
import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.repository.UsageRepository;

@Service
public class UsageService {

	public static final Logger logger = LogManager.getLogger(UsageService.class);
	@Autowired
	UsageRepository usageRepository;
	public Usage addUsage(UsageCrtDto crtDto) {
		try {
			logger.info("{} >> addUsage:[{}],", crtDto);
			Usage usage=new Usage();
			usage.setCustomerId(crtDto.getCustomerId());
			usage.setMeasurementUnit(crtDto.getMeasurementUnit());
			usage.setPhoneNumber(crtDto.getPhoneNumber());
			usage.setQuantity(crtDto.getQuantity());
			usage.setUsageType(crtDto.getUsageType());
			usage.setTimestamp(LocalDateTime.now());
			Usage response=usageRepository.save(usage);
			logger.info("{} >> response:[{}],", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			return new Usage();
		}
	}

}
