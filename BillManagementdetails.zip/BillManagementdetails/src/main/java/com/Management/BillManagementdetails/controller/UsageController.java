package com.Management.BillManagementdetails.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Management.BillManagementdetails.dto.UsageCrtDto;
import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.service.UsageService;


@RestController
@RequestMapping("usage/")
public class UsageController {
	
	public static final Logger logger = LogManager.getLogger(UsageController.class);
	
	@Autowired
	UsageService usageService;
	
	@PostMapping(path = "addusage", produces = {"application/json", "application/xml"})
    public ResponseEntity<Usage> addUsage(@RequestBody UsageCrtDto crtDto) {
        try {
        	 logger.info("{} >> UsageCrtDto:[{}],", crtDto);
        	 Usage response= usageService.addUsage(crtDto);
        	 logger.info("{} << response:[{}]", response);
        	 return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
        	logger.error("Error saving Usage", e.getMessage());
        	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
