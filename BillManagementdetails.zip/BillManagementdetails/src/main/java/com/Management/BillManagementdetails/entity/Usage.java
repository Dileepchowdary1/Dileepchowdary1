package com.Management.BillManagementdetails.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_usage")
public class Usage {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "usage_type")
    private String usageType;

    @Column(name = "measurement_unit")
    private String measurementUnit;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "quantity")
    private Double quantity;

    @Column(name = "timestamp")
    private LocalDateTime timestamp;

	public Usage() {
	}

	public Usage(Long id, Long customerId, String usageType, String measurementUnit, String phoneNumber,
			Double quantity, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.usageType = usageType;
		this.measurementUnit = measurementUnit;
		this.phoneNumber = phoneNumber;
		this.quantity = quantity;
		this.timestamp = timestamp;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public String getMeasurementUnit() {
		return measurementUnit;
	}

	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Usage [id=" + id + ", customerId=" + customerId + ", usageType=" + usageType + ", measurementUnit="
				+ measurementUnit + ", phoneNumber=" + phoneNumber + ", quantity=" + quantity + ", timestamp="
				+ timestamp + "]";
	}
    
    

}
