package com.Management.BillManagementdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Management.BillManagementdetails.entity.Usage;

@Repository
public interface UsageRepository extends JpaRepository<Usage,Long>{

}
