package com.Management.BillManagementdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillManagementdetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillManagementdetailsApplication.class, args);
	}

}
